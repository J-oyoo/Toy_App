class User < ApplicationRecord
	has_many :microposts
end
